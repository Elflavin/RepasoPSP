package examen.psp.ra2;

public class AreaRestringida {

    public void execute() {

    }
}
