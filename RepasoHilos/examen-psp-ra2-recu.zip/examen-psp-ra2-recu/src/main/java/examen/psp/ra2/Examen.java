package examen.psp.ra2;

public class Examen {

    public static void main(String[] args) {

        AreaRestringida areaRestringida = new AreaRestringida();
        areaRestringida.execute();

    }

}
