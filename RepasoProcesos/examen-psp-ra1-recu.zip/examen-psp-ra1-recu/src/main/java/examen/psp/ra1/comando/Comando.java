package examen.psp.ra1.comando;

public class Comando {

    /**
     * Método a crear, podéis crear otros metodos dentro de esta clase si así lo creeis oprtuno.
     * No es necesario crear nuevas clases dentro del proyecto.
     *
     */
    public void ejecutar() {

    }

}
