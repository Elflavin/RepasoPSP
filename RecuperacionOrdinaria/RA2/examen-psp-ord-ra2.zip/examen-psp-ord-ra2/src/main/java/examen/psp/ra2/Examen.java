package examen.psp.ra2;


public class Examen {
    public static void main(String[] args) {
        Cine c = new Cine();
        c.abrir();
    }
}
